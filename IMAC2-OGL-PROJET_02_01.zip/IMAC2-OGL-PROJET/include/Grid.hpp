#pragma once

#include<array>
#include<vector>
#include "./cube.hpp"
#include "../libs/glimac/include/glm.hpp"
#include "../libs/glimac/include/Program.hpp"


class Grid {
    
    friend class Cube;
    private:
        //Determine a fixed size to the world ( Width*Depth*Height = 20*20*10)
        int g_location[20][20][10] = {-1};
        std::vector<Cube> stockCube;
        GLuint vao;
        GLuint vbo;
        GLuint ibo;
        bool gridDisplay;

    public:
        Grid(const Grid&) = default;
        Grid();

        //Change the value of g_location at the position of the cursor
        std::vector<Cube> &getVectorCube();

        void AddCube(const glm::vec3 &position);
        void deleteCube(const glm::vec3 &position);

        //Modify the bool gridDisplay
        //void displayGrid();

        //To draw the grill if the bool Griddisplay is true
        //void drawGrid();

        ~Grid();
        
};